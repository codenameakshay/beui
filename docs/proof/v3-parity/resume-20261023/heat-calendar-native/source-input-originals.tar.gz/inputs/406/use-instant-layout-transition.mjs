import { rootProjectionNode } from 'motion-dom';

function useInstantLayoutTransition() {
    return startTransition;
}
function startTransition(callback) {
    if (!rootProjectionNode.current)
        return;
    rootProjectionNode.current.isUpdating = false;
    rootProjectionNode.current.blockUpdate();
    callback && callback();
}

export { useInstantLayoutTransition };
//# sourceMappingURL=use-instant-layout-transition.mjs.map
