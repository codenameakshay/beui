import { MotionGlobalConfig } from 'motion-utils';
import { acceleratedValues } from '../utils/accelerated-values.mjs';
import { hasBrowserOnlyColors } from '../utils/is-browser-color.mjs';

const colorProperties = new Set([
    "color",
    "backgroundColor",
    "outlineColor",
    "fill",
    "stroke",
    "borderColor",
    "borderTopColor",
    "borderRightColor",
    "borderBottomColor",
    "borderLeftColor",
]);
/**
 * WAAPI runs on the browser's clock, so on a manual clock every animation
 * runs in JS where processFrame can drive it. Set the flag before starting
 * animations: running WAAPI animations stay on the browser's clock.
 */
const supportsWaapi = () => !MotionGlobalConfig.useManualTiming &&
    Object.hasOwnProperty.call(Element.prototype, "animate");
function supportsBrowserAnimation(options) {
    const { motionValue, name, repeatDelay, repeatType, damping, type, keyframes, } = options;
    /**
     * Most values can't be accelerated at all, so check the name before
     * looking at the element or its props.
     */
    if (!name ||
        !(acceleratedValues.has(name) || colorProperties.has(name))) {
        return false;
    }
    const subject = motionValue?.owner?.current;
    /**
     * We use instanceof checks instead of isHTMLElement()/isSVGElement()
     * because we explicitly **don't** want elements in different timing
     * contexts (i.e. popups) to be accelerated, as it's not possible to sync
     * these animations properly with those driven from the main window
     * frameloop.
     */
    if (!(subject instanceof HTMLElement) &&
        !(subject instanceof SVGElement)) {
        return false;
    }
    const { onUpdate, transformTemplate } = motionValue.owner.getProps();
    return (supportsWaapi() &&
        /**
         * Force WAAPI for color properties with browser-only color formats
         * (oklch, oklab, lab, lch, etc.) that the JS animation path can't parse.
         */
        (acceleratedValues.has(name) ||
            (colorProperties.has(name) &&
                hasBrowserOnlyColors(keyframes))) &&
        (name !== "transform" || !transformTemplate) &&
        /**
         * If we're outputting values to onUpdate then we can't use WAAPI as there's
         * no way to read the value from WAAPI every frame.
         */
        !onUpdate &&
        !repeatDelay &&
        repeatType !== "mirror" &&
        damping !== 0 &&
        type !== "inertia");
}

export { supportsBrowserAnimation, supportsWaapi };
//# sourceMappingURL=waapi.mjs.map
