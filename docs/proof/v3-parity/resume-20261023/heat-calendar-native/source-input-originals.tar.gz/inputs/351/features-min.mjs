"use client";
import { animations } from '../../motion/features/animations.mjs';
import { createDomVisualElement } from './create-visual-element.mjs';

/**
 * @public
 */
const domMin = {
    renderer: createDomVisualElement,
    ...animations,
};

export { domMin };
//# sourceMappingURL=features-min.mjs.map
