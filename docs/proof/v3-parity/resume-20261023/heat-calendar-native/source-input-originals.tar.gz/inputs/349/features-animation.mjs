"use client";
import { animations } from '../../motion/features/animations.mjs';
import { gestureAnimations } from '../../motion/features/gestures.mjs';
import { createDomVisualElement } from './create-visual-element.mjs';

/**
 * @public
 */
const domAnimation = /* @__PURE__ */ Object.assign({ renderer: createDomVisualElement }, animations, gestureAnimations);

export { domAnimation };
//# sourceMappingURL=features-animation.mjs.map
