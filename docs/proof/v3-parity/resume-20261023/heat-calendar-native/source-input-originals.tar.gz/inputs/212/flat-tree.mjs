import { addUniqueItem, removeItem } from 'motion-utils';
import { compareByDepth } from './compare-by-depth.mjs';

class FlatTree {
    constructor() {
        this.children = [];
        this.isDirty = false;
    }
    add(child) {
        addUniqueItem(this.children, child);
        this.isDirty = true;
    }
    remove(child) {
        removeItem(this.children, child);
        this.isDirty = true;
    }
    forEach(callback) {
        this.isDirty && this.children.sort(compareByDepth);
        this.isDirty = false;
        this.children.forEach(callback);
    }
}

export { FlatTree };
//# sourceMappingURL=flat-tree.mjs.map
