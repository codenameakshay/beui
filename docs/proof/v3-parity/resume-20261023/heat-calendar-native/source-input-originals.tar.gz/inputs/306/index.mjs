"use client";
import { jsx } from 'react/jsx-runtime';
import { useContext, useMemo } from 'react';
import { resolveTransition } from 'motion-dom';
import { MotionConfigContext } from '../../context/MotionConfigContext.mjs';
import { useConstant } from '../../utils/use-constant.mjs';

/**
 * `MotionConfig` is used to set configuration options for all children `motion` components.
 *
 * ```jsx
 * import { motion, MotionConfig } from "framer-motion"
 *
 * export function App() {
 *   return (
 *     <MotionConfig transition={{ type: "spring" }}>
 *       <motion.div animate={{ x: 100 }} />
 *     </MotionConfig>
 *   )
 * }
 * ```
 *
 * @public
 */
function MotionConfig({ children, ...config }) {
    /**
     * Inherit props from any parent MotionConfig components
     */
    const parentConfig = useContext(MotionConfigContext);
    config = { ...parentConfig, ...config };
    config.transition = resolveTransition(config.transition, parentConfig.transition);
    /**
     * Don't allow isStatic to change between renders as it affects how many hooks
     * motion components fire.
     */
    config.isStatic = useConstant(() => config.isStatic);
    /**
     * Creating a new config context object will re-render every `motion` component
     * every time it renders. So we only want to create a new one sparingly.
     */
    const context = useMemo(() => config, [
        JSON.stringify(config.transition),
        config.transformPagePoint,
        config.reducedMotion,
        config.skipAnimations,
        config.isValidProp,
    ]);
    return (jsx(MotionConfigContext.Provider, { value: context, children: children }));
}

export { MotionConfig };
//# sourceMappingURL=index.mjs.map
