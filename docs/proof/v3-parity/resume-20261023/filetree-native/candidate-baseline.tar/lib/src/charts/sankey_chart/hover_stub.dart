bool get sankeyHoverCapable => true;
